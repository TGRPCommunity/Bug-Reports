---
name: Bug report
about: Create a bug report to help us improve.
title: ''
labels: ''
assignees: ''
---

**Describe the issue you're facing**

**Steps to reproduce**

**Expected behaviour**

**Screenshots/Video**

**Additional context**

**Any Texture Packs (if so list)**

**Perm ID**
